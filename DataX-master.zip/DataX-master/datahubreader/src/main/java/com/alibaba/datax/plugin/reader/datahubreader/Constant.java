package com.alibaba.datax.plugin.reader.datahubreader;

public class Constant {

    public static String DATETIME_FORMAT = "yyyyMMddHHmmss";
    public static String DATE_FORMAT = "yyyyMMdd";

}
