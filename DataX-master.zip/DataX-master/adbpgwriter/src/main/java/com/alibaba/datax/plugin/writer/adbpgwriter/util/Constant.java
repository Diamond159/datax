package com.alibaba.datax.plugin.writer.adbpgwriter.util;
/**
 * @author yuncheng
 */
public class Constant {
    public static final int DEFAULT_RETRY_TIMES = 3;

    public static final String COLUMN_QUOTE_CHARACTER = "\"";



}
