/**
 * 
 */
package com.alibaba.datax.plugin.writer.gdbwriter.model;

import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * @author jerrywang
 *
 */
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class GdbVertex extends GdbElement {

}
