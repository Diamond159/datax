/**
 * ODPS meta.
 *
 * @since 0.0.1
 */
package com.alibaba.datax.plugin.writer.adswriter.odps;