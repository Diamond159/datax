package com.alibaba.datax.dataxservice.face.domain.enums;

public interface EnumStrVal {
    public String value();
}
