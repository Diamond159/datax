本插件仅在Elasticsearch 5.x上测试




